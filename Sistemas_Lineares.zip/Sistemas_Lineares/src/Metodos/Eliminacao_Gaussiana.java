/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import java.util.Scanner;

/**
 *
 * @author felip
 */
public class Eliminacao_Gaussiana {

    Scanner input = new Scanner(System.in);

    public double Calcula() {
        System.out.println("Informe a quantidade de linhas e colunas da matriz: ");
        int l = input.nextInt();
        int c = input.nextInt();
        //double matriz[][] = new double[l][c];
        double matriz[][] = 
        {{9, -6, -3, -4, -5, -5, -8, 6, -2, 2, -7, -1, 4, -9, 4, 5, 9, 4, 9, -5},
        {-8, 5, -7, -8, 0, 2, 10, -8, -2, -8, 10, -2, -10, 2, 7, -7, 6, -8, -4, -8},
        {0, -1, -3, 9, -5, -4, -7, 8, 0, -3, -1, -2, -8, 10, -1, 5, -9, 10, 1, -9},
        {9, -10, 7, -10, -4, 7, 4, 9, 9, -2, 2, 10, -2, 1, 2, 8, 4, -4, 6, 5},
        {-6, -8, -4, 3, 0, 6, 4, -3, 3, -5, -2, -7, -9, -10, 8, 0, -9, -7, 3, 0},
        {8, 1, 5, -1, -7, 6, -6, -8, -7, 8, 6, 2, -6, -7, 5, 7, -9, -6, 3, -9},
        {7, 1, 3, -6, -9, 4, 0, 5, -4, -2, -2, -2, -6, 0, -6, 0, 4, -3, 0, -6},
        {-8, 6, -1, -9, 0, -10, -10, -10, 5, -10, -2, 4, -10, 2, 7, 1, -5, -6, 0, -4},
        {7, -2, -8, -5, -2, -9, 10, -7, -8, -2, 5, 2, 3, -3, 4, -10, 10, 5, 4, -5},
        {7, -9, 6, 5, 5, -6, -3, -3, 1, -4, 0, -6, 10, 0, 7, 8, -5, 10, -4, -3},
        {6, -9, 4, 5, -1, -5, 10, 10, -8, 9, 3, 9, -9, 6, -10, 5, -1, -7, -5, 3},
        {4, 3, -10, -1, -3, 5, 4, -10, 2, -8, -4, 9, 7, 7, 6, -3, 1, -4, -6, 2},
        {7, 10, 10, 2, 6, -7, 10, 1, 2, 6, -6, 8, 6, 10, 1, -1, 7, -2, 5, 9},
        {-7, 9, 9, -3, 10, 4, 6, 3, -9, -2, -6, -4, -6, 3, -8, -6, 7, 1, 8, -9},
        {1, 1, -4, -4, -4, 1, -5, -6, -4, -1, 5, 7, -2, -5, 9, -2, 0, 4, 3, -8},
        {5, 0, -10, -6, -7, -1, 8, 4, 1, -10, 4, -9, -4, -7, -4, 3, 5, 8, 2, 6},
        {-10, -2, 10, 7, -7, 5, -8, 6, 5, 8, 9, -7, -5, -10, 7, -1, -2, -4, 2, 7},
        {-6, 6, 1, 4, 0, -2, 3, -8, 9, -6, 7, -6, -4, -2, 10, 7, 10, 1, 1, 2},
        {1, -8, 8, -9, 10, 7, -5, 5, -2, -9, 10, 5, 6, 0, -8, -8, -3, 7, -7, -1},
        {6, 9, -7, -4, -2, 0, 3, 1, -9, -7, 0, -8, 1, -5, -8, -4, 10, -3, 8, 6}};

        /*for (int i = 0; i < l; i++) {
            for (int j = 0; j < c; j++) {
                System.out.println("Informe o valor na posição [" + i + "]" + "[" + j + "] :");
                matriz[i][j] = input.nextDouble();
            }
        }*/

        //Printa Matriz
        for (int i = 0; i < l; i++) {
            System.out.println();
            for (int j = 0; j < c; j++) {
                System.out.print("[" + matriz[i][j] + "]");
            }

        }

        int pivo = 0;
        int in = 1;
        do {
            for (int i = in; i < l; i++) {
                double m = matriz[i][pivo] / matriz[pivo][pivo];
                for (int j = 0; j < c; j++) {
                    matriz[i][j] = matriz[i][j] - m * matriz[pivo][j];
                }
            }
            in++;
            pivo++;
        } while (pivo != l - 1);

        //Printa Matriz
        System.out.println("");
        for (int i = 0; i < l; i++) {
            System.out.println();
            for (int j = 0; j < c; j++) {
                System.out.print("[" + matriz[i][j] + "]");
            }
        }

        double aux = 0;
        int n = l;
        double vet[] = new double[l];
        vet[l - 1] = matriz[l - 1][c - 1] / matriz[l - 1][l - 1];
        int lin = l - 2;
        int col = c - 2;
        System.out.println("\nX" + n + " = " + vet[l - 1]);
        for (int i = lin; i > -1; i--) {
            n--;
            for (int j = col; j > 0; j--) {
                aux = aux + vet[j] * matriz[i][j];
            }
            vet[i] = (matriz[i][c - 1] - aux) / matriz[i][i];
            System.out.println("X" + n + " = " + vet[i]);
            aux = 0;
        }

        return 0;
    }

}
